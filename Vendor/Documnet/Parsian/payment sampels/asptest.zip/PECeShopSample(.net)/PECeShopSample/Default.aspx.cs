using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Net;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using Common;

namespace PECeShopSample
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class Default : System.Web.UI.Page
	{
		#region Web Form Designer generated code

		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			this.btnReversal.Click += new System.EventHandler(this.btnReversal_Click);
			this.btnVoid.Click += new System.EventHandler(this.btnVoid_Click);
			this.btnRefund.Click += new System.EventHandler(this.btnRefund_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		protected System.Web.UI.WebControls.Label Label14;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox txtSaleOrder;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox txtSaleAmount;
		protected System.Web.UI.WebControls.Button btnStart;
		protected System.Web.UI.WebControls.Label SaleAlert;
		protected System.Web.UI.WebControls.Label Label15;
		protected System.Web.UI.WebControls.Label Label16;
		protected System.Web.UI.WebControls.TextBox txtReversalOrder;
		protected System.Web.UI.WebControls.Label Label17;
		protected System.Web.UI.WebControls.TextBox txtOrderToReversal;
		protected System.Web.UI.WebControls.Button btnReversal;
		protected System.Web.UI.WebControls.Label ReversalAlert;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label18;
		protected System.Web.UI.WebControls.TextBox txtVoidOrder;
		protected System.Web.UI.WebControls.Label Label19;
		protected System.Web.UI.WebControls.Button btnVoid;
		protected System.Web.UI.WebControls.Label VoidAlert;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label9;
		protected System.Web.UI.WebControls.TextBox txtRefundOrder;
		protected System.Web.UI.WebControls.Label Label11;
		protected System.Web.UI.WebControls.Button btnRefund;
		protected System.Web.UI.WebControls.Label RefundAlert;
		protected System.Web.UI.WebControls.TextBox txtOrderToRefund;
		protected System.Web.UI.WebControls.TextBox txtRefundAmount;
		protected System.Web.UI.WebControls.TextBox txtOrderToVoid;
		protected System.Web.UI.WebControls.Label Label5;


		private PEC.EShopService service;
		private void Page_Load(object sender, System.EventArgs e)
		{
			service = new PEC.EShopService();
		}

		private void btnStart_Click(object sender, System.EventArgs e)
		{
			ClearAlerts();
			try
			{
				long authority=0;
				byte status=0;
				int amount = int.Parse(txtSaleAmount.Text);
				int orderId = int.Parse(txtSaleOrder.Text);

				string callbackPage = ConfigManager.GetValue("callbackPage");
				string pgwPage = ConfigManager.GetValue("pgwPage");

				service.PinPaymentRequest(ConfigManager.GetValue("loginAccount"), amount, orderId, callbackPage, ref authority, ref status);

				// here eShops has to register the authority, for future needs, such as integrity 
				// checks in settlement time.
				if (status == 0)
					Response.Redirect(pgwPage+"?au="+authority.ToString(), true);

				SaleAlert.Text = "Status : " + ((PgwStatus)status).ToString();
			}
			catch (Exception err)
			{
				SaleAlert.Text = "ERROR : " + err.Message.ToString();
			}
		}

		private void btnReversal_Click(object sender, System.EventArgs e)
		{
			ClearAlerts();
			try
			{
				byte status=0;
				int orderId = int.Parse(txtReversalOrder.Text);
				int orderToRevsrsal = int.Parse(txtOrderToReversal.Text);
				service.PinReversal(ConfigManager.GetValue("loginAccount"),orderId, orderToRevsrsal, ref status);

				ReversalAlert.Text = "Status : " + ((PgwStatus)status).ToString();
			}
			catch (Exception err)
			{
				ReversalAlert.Text = "ERROR : " + err.Message.ToString();
			}
		}

		private void btnVoid_Click(object sender, System.EventArgs e)
		{
			ClearAlerts();
			try
			{
				byte status=0;
				int orderId = int.Parse(txtVoidOrder.Text);
				int orderToVoid = int.Parse(txtOrderToVoid.Text);
				service.PinVoidPayment(ConfigManager.GetValue("loginAccount"),orderId, orderToVoid, ref status);

				VoidAlert.Text = "Status : " + ((PgwStatus)status).ToString();
			}
			catch (Exception err)
			{
				VoidAlert.Text = "ERROR : " + err.Message.ToString();
			}
		}

		private void btnRefund_Click(object sender, System.EventArgs e)
		{
			ClearAlerts();
			try
			{
				byte status=0;
				int orderId = int.Parse(txtRefundOrder.Text);
				int orderToRefund = int.Parse(txtOrderToRefund.Text);
				int amount = int.Parse(txtRefundAmount.Text);
				service.PinRefundPayment(ConfigManager.GetValue("loginAccount"),orderId, orderToRefund, amount, ref status);

				RefundAlert.Text = "Status : " + ((PgwStatus)status).ToString();
			}
			catch (Exception err)
			{
				RefundAlert.Text = "ERROR : " + err.Message.ToString();
			}
		}

		private void ClearAlerts()
		{
			SaleAlert.Text = "";
			ReversalAlert.Text = "";
			VoidAlert.Text = "";
		}
	}
}
